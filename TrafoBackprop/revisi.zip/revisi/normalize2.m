function newValue = normalize2( originalValue, minOriginalRange, maxOriginalRange)
 deltaVal = maxOriginalRange - minOriginalRange;
 newValue = (originalValue - minOriginalRange)/deltaVal;
end