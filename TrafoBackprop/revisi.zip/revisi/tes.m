clear % clear "Workspace"
clc   % clear "Command Window"
close all % close "All Window"


% Load data
data = xlsread('dataheader5new.xlsx');

% Normalisasi input dan output jadi 1
IminVal = min(data);
minData = min(IminVal);
ImaxVal = max(data);
maxData = max(ImaxVal);

input = transpose([data(:,1),data(:,2),data(:,3),data(:,4),data(:,5)]);
target = transpose([data(:,6)]);

[nrow,ncol]=size(input);
for ii=1:nrow
    for jj=1:ncol
        inputn(ii,jj) = normalize2 (input(ii,jj),minData,maxData);
    end
end

[nrow,ncol]=size(target);
for ii=1:nrow
    for jj=1:ncol
        targetn(ii,jj) = normalize2 (target(ii,jj),minData,maxData);
    end
end

load mynet;
%load mynet191648;
% Test jaringan
estn = sim(net,inputn);
est = denormalize2(estn,minData,maxData)


% parameter error
errorabs  = abs( est - target );
MSE = power(errorabs,2)

[nrow,ncol]=size(est);
for ii=1:nrow
    for jj=1:ncol
            akurasi (ii,jj) =  100 - ((errorabs(ii,jj)/est(ii,jj))*100);
    end
end

