
function newValue = denormalize2( originalValue, minOriginalRange, maxOriginalRange)
 deltaVal = maxOriginalRange - minOriginalRange;
 newValue = originalValue*deltaVal + minOriginalRange;
end